import asyncio

import schemas
from core.logging_config import logger
from ghp import github_parser

from .base import BaseService


class RepositoriesService(BaseService):
    table_name = "repositories"
    schemaCU = schemas.RepositoryCU

    def __init__(self):
        super().__init__()
        self._initial_query = f"""
            CREATE TABLE IF NOT EXISTS {self.table_name} (
                id SERIAL PRIMARY KEY,
                repo VARCHAR NOT NULL,
                owner VARCHAR NOT NULL,
                position_cur INTEGER DEFAULT null,
                position_prev INTEGER DEFAULT null,
                stars INTEGER DEFAULT null,          
                watchers INTEGER DEFAULT null,
                forks INTEGER DEFAULT null,           
                open_issues INTEGER DEFAULT null,
                language VARCHAR DEFAULT null,
                UNIQUE (owner, repo)
            );
            CREATE INDEX IF NOT EXISTS idx_{self.table_name}_owner_repo ON {self.table_name} (owner, repo);
        """

    def _update_query(self, repo: schemas.RepositoryCU) -> str:
        return f"""
            UPDATE {self.table_name} SET {(
            ", ".join(
                [
                    f"{col} = {value}"
                    for col, value in zip(schemas.RepositoryCU.model_fields.keys(), repo.model_dump().values())
                ]
            )
        )}
            WHERE repo = {repo.repo} AND owner = {repo.owner}
        """

    @staticmethod
    def _prepare_before_pushing(repos_list: list[schemas.Repository]) -> list[schemas.RepositoryCU]:
        repos_dict = {
            (repo.repo, repo.owner): repo
            for repo in repos_list
        }
        sorted_repos = sorted(repos_dict.values(), key=lambda r: -r.stars)
        return [
            schemas.RepositoryCU(
                repo=f"'{item.repo}'",
                owner=f"'{item.owner}'",
                forks=f"'{item.forks}'",
                watchers=f"'{item.watchers}'",
                open_issues=f"'{item.open_issues}'",
                language="'{}'".format(item.language) if item.language else "null",
                position_prev=f"'{item.position_cur}'" if item.position_cur else "null",
                stars=f"'{item.stars}'",
                position_cur=f"'{i + 1}'",
            )
            for i, item in enumerate(sorted_repos)
        ]

    @staticmethod
    def _repos_different(old_repo: schemas.Repository, cur_repo: schemas.RepositoryCU) -> bool:
        return not all(
            (
                old_repo.repo == cur_repo.repo.strip("'"),
                old_repo.owner == cur_repo.owner.strip("'"),
                old_repo.stars == int(cur_repo.stars.strip("'")),
                old_repo.position_cur == int(cur_repo.position_cur.strip("'")),
                old_repo.open_issues == int(cur_repo.open_issues.strip("'")),
                old_repo.forks == int(cur_repo.forks.strip("'")),
                old_repo.watchers == int(cur_repo.watchers.strip("'")),
                (
                        old_repo.language is None and cur_repo.language == "null" or
                        old_repo.language == cur_repo.language.strip("'")
                ),
            )
        )

    def _select_top_repos_query(self) -> str:
        return f"""
            SELECT * FROM {self.table_name}
            WHERE position_cur IS NOT null AND stars IS NOT null
            ORDER BY stars DESC;
        """

    async def get_top_repos_by_stars(self) -> list[schemas.Repository]:
        query = self._select_top_repos_query()
        result = await self.execute(query, fetch=True)
        logger.debug(f"q = {query}, r = {result}")

        return [
            schemas.Repository(**item)
            for item in result
        ]

    async def update_top_repos(self) -> None:
        old_repos = await self.get_top_repos_by_stars()
        old_repos_dict = {
            (repo.repo, repo.owner): repo
            for repo in old_repos
        }
        current_repos = github_parser.parse_top_repos()
        repos_to_push = self._prepare_before_pushing(old_repos + current_repos)

        tasks = list()
        columns = self._columns()

        for cur_repo in repos_to_push:
            old_repo = old_repos_dict.get((cur_repo.repo.strip("'"), cur_repo.owner.strip("'")), None)
            if old_repo:
                query = self._update_query(cur_repo) if self._repos_different(old_repo, cur_repo) else None
            else:
                query = self._insert_many_query([self._format_data(cur_repo)], columns)

            if query:
                tasks.append(self.execute(query))

        await asyncio.gather(*tasks)

        logger.info("Updated top repositories")


repos_service = RepositoriesService()
