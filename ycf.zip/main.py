import json

from services.repos import repos_service

from ghp import github_parser


async def handler(event, context):
    result = list()

    if event.get("httpMethod") == "POST":
        action = event.get("queryStringParameters").get("action", None)
        body = json.loads(event.get("body", "{}"))
        owner, repo_name, latest_date = body.get("owner", None), body.get("repo_name", None), body.get("latest_date",
                                                                                                       None)
        if action == "parse_activity" and not all([param is None for param in (owner, repo_name)]):
            result = github_parser.parse_activity(repo_name, owner, latest_date)

    if event.get("messages", None):
        await repos_service.update_top_repos()

    return {
        'statusCode': 200,
        'body': json.dumps(result),
    }
