from pydantic import PostgresDsn
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ------------- DB ----------------------------------------------
    PSQL_URL: PostgresDsn

    # ------------- GITHUB JWT --------------------------------------
    TOKEN: str


settings = Settings()
