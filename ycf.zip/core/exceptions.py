class DateRangeException(Exception):
    pass


class NoSuchRepository(Exception):
    pass


class RateLimitExceeded(Exception):
    pass
