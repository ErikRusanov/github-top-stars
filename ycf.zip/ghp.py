import re
from datetime import datetime, date

import requests
from core.config import settings
from core.exceptions import RateLimitExceeded
from core.logging_config import logger
from requests import RequestException

import schemas


class GHParser:
    def __init__(self):
        self._headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Authorization": f"Bearer {settings.TOKEN}"
        }

        self._search_repos_url = "https://api.github.com/search/repositories"
        self._search_repos_params = {
            "sort": "stars",
            "q": "stars:>0",
            "per_page": 100
        }

        self._list_repo_activity_url = "https://api.github.com/repos/{owner}/{repo_name}/activity"
        self._list_repo_activity_params = {
            "time_period": "year",
            "per_page": 100
        }

    def _send_request(self, url: str, params: dict) -> tuple[dict, str | None]:
        try:
            resp = requests.get(
                headers=self._headers,
                url=url,
                params=params
            )

            data = resp.json()
            if isinstance(data, dict) and "API rate limit exceeded" in data.get("msg", ""):
                raise RateLimitExceeded

            return data, resp.headers.get("Link", None)
        except RequestException as e:
            logger.error(f"Can't parse data from {url}. Error: {e}")

        return dict(), None

    @staticmethod
    def _convert_date(item: dict) -> date:
        _format = "%Y-%m-%dT%H:%M:%SZ"
        return datetime.strptime(item.get("timestamp"), _format).date()

    @staticmethod
    def _next_url(link: str) -> str | None:
        if link is None or 'rel="next"' not in link:
            return

        if url := re.match(r"<https?://[^>]+after=[^>]+>", link):
            return url.group()[1:-1]

    def parse_activity(self, repo_name: str, owner: str, latest_date: date | None) -> list[tuple[date, str]]:
        url = self._list_repo_activity_url.format(owner=owner, repo_name=repo_name)
        items = list()
        latest_date = datetime.strptime(latest_date, "%Y-%m-%d").date() if isinstance(latest_date, str) else latest_date

        while True:
            data, link = self._send_request(
                url=url,
                params=self._list_repo_activity_params,
            )

            if not isinstance(data, list):
                break

            if latest_date and self._convert_date(data[0]) <= latest_date:
                break

            items.extend(data)

            if (url := self._next_url(link)) is None:
                break

        return [
            (item.get("timestamp"), item.get("actor").get("login"))
            for item in items
        ]

    def parse_top_repos(self) -> list[schemas.Repository]:
        data, _ = self._send_request(
            url=self._search_repos_url,
            params=self._search_repos_params
        )

        return [
            schemas.Repository(
                repo=item.get("full_name"),
                owner=item.get("owner").get("login"),
                forks=item.get("forks"),
                watchers=item.get("watchers"),
                open_issues=item.get("open_issues"),
                language=item.get("language", None),
                position_prev=None,
                stars=item.get("stargazers_count"),
                position_cur=0,
            )
            for i, item in enumerate(items)
        ] if (items := data.get("items"), None) else list()


github_parser = GHParser()
