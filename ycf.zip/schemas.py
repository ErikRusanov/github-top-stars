from pydantic import BaseModel


class _RepositoryBase(BaseModel):
    position_cur: int | None = None
    position_prev: int | None = None
    stars: int | None = None
    watchers: int | None = None
    forks: int | None = None
    open_issues: int | None = None
    language: str | None = None


class Repository(_RepositoryBase):
    id: int | None = None
    repo: str
    owner: str


class RepositoryCU(BaseModel):
    position_cur: str
    position_prev: str
    stars: str
    watchers: str
    forks: str
    open_issues: str
    language: str
    repo: str
    owner: str
